export const AccountType = {
    SAVING: 'SAVING',
    CURRENT: 'CURRENT',
  };