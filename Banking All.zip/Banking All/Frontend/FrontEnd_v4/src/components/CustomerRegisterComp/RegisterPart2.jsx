import React from 'react';

function RegisterPart2({ formData, handleChange, handleSubmit }) {
  return (
    <div>
      <h2>Register - Part 2</h2>
    
      {/* Add more fields */}
      <button onClick={handleSubmit}>Register</button>
    </div>
  );
}

export default RegisterPart2;
