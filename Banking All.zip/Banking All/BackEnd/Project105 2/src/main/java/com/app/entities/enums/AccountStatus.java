package com.app.entities.enums;

public enum AccountStatus {

	PENDING_APPROVAL, ACTIVE, INACTIVE, CLOSED, BLOCKED;
}
