package com.app.entities.enums;

public enum TransactionMode {
	
	ONLINE_BANKING,
	DEBIT_CARD,
	CASH,
	ATM

}

