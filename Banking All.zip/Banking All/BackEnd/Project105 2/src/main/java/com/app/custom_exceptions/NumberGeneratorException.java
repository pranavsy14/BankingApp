package com.app.custom_exceptions;

public class NumberGeneratorException extends RuntimeException {

	public NumberGeneratorException(String me) {
		super(me);
	}

}
