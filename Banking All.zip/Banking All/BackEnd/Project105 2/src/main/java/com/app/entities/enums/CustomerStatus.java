package com.app.entities.enums;

public enum CustomerStatus {

	PENDING_APPROVAL, ACTIVE, INACTIVE, CLOSED, BLOCKED;
}
