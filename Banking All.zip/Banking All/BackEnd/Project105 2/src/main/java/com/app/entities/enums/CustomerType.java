package com.app.entities.enums;

public enum CustomerType {
	
	STUDENT,
	NRI,
	SENIOR_CITIZEN,
	GENERAL

}
