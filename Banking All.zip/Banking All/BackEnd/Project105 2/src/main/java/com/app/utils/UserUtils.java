package com.app.utils;

public class UserUtils {
	
//	static linkAccountToUser(User u) {
//		u.set
//	}

}
