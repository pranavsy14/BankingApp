package com.app.entities.enums;

public enum TransactionStatus {
	PENDING,
    COMPLETED,
    FAILED,
    CANCELED;
}
