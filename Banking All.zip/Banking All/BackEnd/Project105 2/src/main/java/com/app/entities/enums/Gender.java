package com.app.entities.enums;

public enum Gender {
	
	MALE,
	FEMALE,
	OTHER

}
