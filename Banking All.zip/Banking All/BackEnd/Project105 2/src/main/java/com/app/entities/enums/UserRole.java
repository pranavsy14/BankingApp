package com.app.entities.enums;

public enum UserRole {

	ROLE_CUSTOMER, ROLE_MANAGER, ROLE_CLERK
}
