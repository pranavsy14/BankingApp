package com.app.entities.enums;

public enum Relation {

	SPOUSE,
    CHILD,
    PARENT,
    GUARDIAN,
    FRIEND,
    OTHER
}
