package com.app.entities.enums;

public enum LoanInstallmentStatus {
	
	PAID,
	OVERDUE,
	PENDING,
	PARTIALLY_PAID

}
